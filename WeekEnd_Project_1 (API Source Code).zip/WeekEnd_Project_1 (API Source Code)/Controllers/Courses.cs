﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WeekEnd_Project_1.Models;

namespace WeekEnd_Project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Courses : ControllerBase
    {
        private readonly string _connectionString;

        public Courses(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
    }
}
