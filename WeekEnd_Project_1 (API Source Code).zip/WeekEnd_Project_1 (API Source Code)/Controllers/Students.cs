﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using WeekEnd_Project_1.Models;

namespace WeekEnd_Project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Students : ControllerBase
    {
        private readonly string _connectionString;

        public Students(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }


        //Read Data

        [HttpGet]
        public IActionResult GetAllStudents()
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("ListAllStudents", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        students.Add(new Student
                        {
                            StudentID = (int)reader["StudentID"],
                            FirstName = (string)reader["FirstName"],
                            LastName = (string)reader["LastName"],
                            Age = (int)reader["Age"],
                            CourseID = (int)reader["CourseID"]
                        });
                    }
                    connection.Close();
                }
            }
            return Ok(students);
        }

        // Create Data
        [HttpPost]
        public IActionResult AddStudent(Student student)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddStudent", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FirstName", student.FirstName);
                    command.Parameters.AddWithValue("@LastName", student.LastName);
                    command.Parameters.AddWithValue("@Age", student.Age);
                    command.Parameters.AddWithValue("@CourseID", student.CourseID);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }

            return Ok();
        }


        //Update Data
        [HttpPut("{ID}")]
        public IActionResult UpdateStudent(int ID, Student student)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    command.Parameters.AddWithValue("@StudentID", ID);
                    command.Parameters.AddWithValue("@Age", student.Age);
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok(student);

        }

        //Delete Data
        [HttpDelete("{ID}")]
        public IActionResult DeleteStudent(int ID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", ID);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok();
        }

        //Advanced API Calls

        //1. Students older than 20

        [HttpGet("OldThan20")]
        public IActionResult Olderthan20()
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("OldThan20", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        students.Add(new Student
                        {
                            StudentID = (int)reader["StudentID"],
                            FirstName = (string)reader["FirstName"],
                            LastName = (string)reader["LastName"],
                            Age = (int)reader["Age"],
                            CourseID = (int)reader["CourseID"]
                        });
                    }
                }
                connection.Close();
            }
            return Ok(students);
        }


        //2. Students in specific course 

        [HttpGet("SpecificCourse/{course_name}")]
        public IActionResult Specific_Course(string course_name)
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AllStudentsInASpecificCourse", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    command.Parameters.AddWithValue("@CourseName", course_name);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        students.Add(new Student
                        {
                            StudentID = (int)reader["StudentID"],
                            FirstName = (string)reader["FirstName"],
                            LastName = (string)reader["LastName"],
                            Age = (int)reader["Age"],
                            CourseID = (int)reader["CourseID"]
                        });
                        }
                    }
                    connection.Close();
                }
            return Ok(students);
        }
    

        //3. Most Popular course


        [HttpGet("MostPopularCourse")]
        public IActionResult MostPopularCourse()
        {
            string course = "";
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("PopularCourse", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        course = (string)reader["CourseName"];
                    }
                    connection.Close();
                }
            }
            return Ok(course);

        }
    }
}
