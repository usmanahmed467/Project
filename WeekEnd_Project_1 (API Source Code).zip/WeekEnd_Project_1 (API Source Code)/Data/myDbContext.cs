﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using WeekEnd_Project_1.Models;

namespace WeekEnd_Project_1.Data
{
    public class myDbContext : DbContext
    {
        public myDbContext(DbContextOptions<myDbContext> options)
        : base(options)
        {
        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
    }
}
