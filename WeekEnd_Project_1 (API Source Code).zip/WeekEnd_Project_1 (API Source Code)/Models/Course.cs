﻿namespace WeekEnd_Project_1.Models
{
    public class Course
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; } = "";
    }
}
